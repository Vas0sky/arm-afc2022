===============CAR DATA SHEET===============
Car name: Acclaim F1 2022
Car type: Remodel
Acceleration (0-45 Kph/27 Mph): 1.060 sec.
Acceleration (0-Max speed): 5.971 sec.
Max speed: 74.3 Kph/46.1 Mph

===============INSTRUCTIONS AND OTHER===============
Author: NVT_06
Author contacts: 
-marco.nvt7@gmail.com (e-mail)
-NVT_06#7492 (Discord DM)
Programs used: 
-Corel PaintShop Pro 2021 (paint) 
-Blender 2.93 with Dummiesman's Plugin (model)
Recommended RV version: any RVGL, preferably the latest
Install: extract folder in "Re-Volt\cars"
Permissions: It can be repainted, as long as you credit me in the readme or any description
Where to get it:
-Re-Volt World (http://revoltworld.net)
-Alias Re-Volt Master: (http://aliasrevoltmaster.com)

Future updates coming soon.
Thank you for downloading my car! Enjoy ;)

