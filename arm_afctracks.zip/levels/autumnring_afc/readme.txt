Information
-----------------
Track Name:	Autumn Ring
Length:		582 meters
Difficulty	Extreme
Author:		Saffron
Challenge time:	37:000 (Stock Pros)


Description
-----------------
Gran Turismo is a racing game franchise known by many, with its sheer quality of quantity being its key selling point. Autumn Ring is one of the long-standing originals designs of the series, boasting a very intricate balance between having an exciting raceline, and having plenty of eyecandy to keep the player at awe.

I wanted to recreate this track since it's more complex than the other tracks I've done before.

The track is mostly accurate, the elevation changes are as close to the original as possible, but some scenery changes had to be made to ensure it fit in the game, because of RV's camera and its POV, compared to the one in GT.

But I am pleased with the end result, with the atmosphere and the look being instantly recognizable. I spent countless hours driving around this track in GT1 and GT2 to make the recreation as close to the original as possible, and fill the gaps wherever they were required. A lot of textures are printscreens from the original game as well.


Requirements
-----------------
The latest RVGL patch is required for the track to function properly.


Credits
-----------------
The Internet and Polyphony Digital for the textures
Scloink (I think) for the truck model
The Blender Foundation for Blender
Marv for his Blender plug-in
Huki and Marv (again) for RVGL
ARM for the Camera nodes tutorial
Rick Brewster for Paint.NET
Shara, among others for testing out of the track and giving feedback
Everyone in Re-Volt Discord


Permissions
-----------------
This track may not be distributed anywhere else outside of Re-Volt Zone and Re-Volt I/O content packs. You are welcome however, to convert this track to another game, just make sure to give credit to Polyphony Digital and myself.